#include <iostream>
#include <string>
#include"Map.h"

using namespace std;

int Map::GetMap_count() { return Map_Count; }
string Map::GetMap_Name() { return Map_Name; }