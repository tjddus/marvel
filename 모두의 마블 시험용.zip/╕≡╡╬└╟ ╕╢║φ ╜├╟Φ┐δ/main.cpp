#include <iostream>
#include<string>
#include"Map.h"
#include"Map_detail.h"
#include"player.h"
#include "GAME.h"
using namespace std;

int main() {
	Game game;
	game.Setting_marvel();
	game.GAME();

	return 0;
}